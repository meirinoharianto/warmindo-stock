test printer<br>
<center><?= $pp->nama_toko; ?><br>
    <left><?= $pp->alamat_toko; ?><br>
        <right><?= $pp->alamat_toko; ?><br>
            <center><?= $pp->alamat_toko; ?><br>